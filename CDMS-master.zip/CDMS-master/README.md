### CDMS
Crop Detail Management System for Department of Agriculture, North Central Province

Facilitates analysis, management and illustration of crops planted within the province
