<html>
<head>
     <title> REGISTER FORM</title>
</head>
<body background="se.jpg">
       <form action="insert.php" method="post">
       <center><table  width="500" height="400"></center>
       	<td colspan="2" align="center" background="se1.jpg"><font color="white"><h2><b><u>REGISTER FORM</b></u></h2></td>
        <tr>
        <td align="center"><b> NAME</b></td>
      <td>
   <input type="text" name="name" placeholder="Rama" required=""></tr>
   </td>

<tr>
  <td align="center"> <b>MOBILE</b></td>
      <td><input type="phone" name="phone" placeholder="123456789" required="">
      </tr>
   </td>
<tr>
   <td align="center"><b> EMAIL</b></td>
      <td><input type="mail" name="email" placeholder="Email @gmail.com" required="xxx@gmail.com">
       </td>
   </tr>
   <tr>
    <td align="center"><b> PASSWORD</b></td>
 <td><input type="password" name="password" placeholder="**12ee**" required=" ">
  </td>
</tr>
<tr>
<td align="center"> <b>GENDER</b></td>
      <td><input type="radio" name="gender" value="M"><b>MALE</b>
    <input type="radio" name="gender" value="F"><b>FEMALE</b>
   </td>
</tr>
  <tr>
  	<td colspan="2" align="center" ><input type="submit"  value="SUBMIT"name="submit">
     
  	</td>
  </tr>
 
</tr>
</table>
</form>
 
  
</tr>
</body>
</html>
 


