<html>
<head>
     <title> LOGIN FORM</title>
</head>
<body background="se.jpg">
       <form action="key1.php" method="post">
       <center><table  width="400" height="300"></center>
       	<td colspan="2" align="center" background="se1.jpg"><font color="white"><h2><b><u>ADMIN PORTAL</b></u></h2></td>
        <tr>
        <td align="center"><font color="orange"><b><h3><u>ADMIN_ID</b></td></u></h3>
      <td>
   <input type="password" name="id" placeholder=" aaa@gmail.com" required=""></tr>
   </td>

<tr>
  <td align="center"> <font color="orange"><b><u><h3>PASSWORD</b></td></u></h3>
      <td><input type="password" name="password" placeholder="***12edk***" required="">
      </tr>
   </td>
  <tr>
  	<td colspan="2" align="center" ><input type="submit"  value="SUBMIT"name="submit">
     
  	</td>
  </tr>
 
</tr>
</table>
</form>
 
  
</tr>
</body>
</html>
 


