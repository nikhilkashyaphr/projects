<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body background="yo.jpg">
	<form action="old.php" method="post">
    <center><table  width="500" height="400"></center>
      <td colspan="2" align="center" bgcolor="sky blue"><font color="white"><h2><b><u> INSERT CROP DETAILS </b></u></h2>

<tr>
  <td align="center"> <b>Crop Name</b></td>
      <td><input type="text" name="cropname" placeholder="aaa" required="">
      </tr>
   </td>
    <td align="center"> <b>Soil type</b></td>
      <td><input type="text" name="soiltype" placeholder="black/red" required="">
      </tr>
   </td>
    <td align="center"> <b>Duration</b></td>
      <td><input type="text" name="duration" placeholder="8 months" required="">
      </tr>
   </td>
    <td align="center"> <b>Fertilizer</b></td>
      <td><input type="text" name="fertilizer" placeholder="20:20:17" required="">
      </tr>
   </td>
    <td align="center"> <b>Insecticide</b></td>
      <td><input type="text" name="insecticide" placeholder="russy" required="">
      </tr>
   </td>
    <tr>
  	<td colspan="2" align="center" bgcolor="pink" ><input type="submit"  value="DONE"name="submit">
  	</td>
  </tr>
</tr></form>
</body>
</html>