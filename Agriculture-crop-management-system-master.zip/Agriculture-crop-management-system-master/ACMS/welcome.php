<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>welcome page</title>
    
  </head>
  <body background="hh1.jpg">


<section class="b1">
  <div class="in1">
    <div class="content">
    	<form>
    		<table align="center" width="500" height="60"></center>
       	<td colspan="2" align="center" background="home.jpg"><font color="purple"><h2><b><u>WELCOME TO ACMS</b></u></h2></td>
        <tr></table>

     </form>
<a href="https://www.youtube.com/watch?v=FNn5DB1Zen4" type="button"><button style="background-color:rgb(red);:color:white;width:205px; height: 30px;"value="HOME">MODREN TECH</button>
<a href="new.php" type="button"><button style="background-color:rgb(red);:color:white;width:205px; height: 30px;"value="">INSERT</button>
<a href="html1.php" type="button"><button style="background-color:rgb(red);:color:white;width:205px; height: 30px;"value=""> CONTACT US</button>



<a href="home.php" type="button"><button  style="background-color:rgb(red);:color:white;width:205px; height: 30px;"value=""> LOG OUT</button>


<A href="see.php" type="button"><button  style="background-color:rgb(red);:color:white;width:205px; height: 30px;"value="">CROPS</button>
  <A href="loginpage.php" type="button"><button  style="background-color:rgb(red);:color:white;width:205px; height: 30px;"value="">DELETE</button><br></A></A></a></a>
    <br>
    <br>
    <br>
<div class= "center">
    <video align="center" width="850"autoplay>
      <source src="cool.mp4" type="video/mp4">
      </center>
      </video>
    </div>


</u></b></h1></center></div></div></section></body></html></tr></b></h