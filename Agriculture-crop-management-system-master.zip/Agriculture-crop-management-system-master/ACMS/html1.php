<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Our Team Section</title>
  <link rel="stylesheet" href="styles.css">
</head >
<body >

<div class="wrapper">
  <h1>Our Team</h1>
  <div class="team">
    <div class="team_member">
      <div class="team_img">
        <img src="rr.png" alt="Team_image">
      </div>
      <h3> YASHWANTH T U</h3>
      <p class="role">CSE STUDENT</p>
      <p>1RI17CS054<br>
        Computer Science Dept<br>
        5th Sem,3rd Year<br>
        RR Instituse of Technology<br>
       <lin> yashwanthtu1999@gmail.com</lin>
          <u>7411188939 </u> </p>
    </div>
    <div class="team_member">
      <div class="team_img">
        <img src="team2.png" alt="Team_image">
      </div>
      <h3> CHARAN K </h3>
      <p class="role">CSE STUDENT</p>
      <p>1RI16CS013<br>
        Computer Science Dept<br>
        5th Sem,3rd Year<br>
         RR Instituse of Technology<br>
        charan1kh@gmail.com<br>
        <u>7406867375  </u></p>
      </div>
    
  
  </div>
</div>  

</body>
</html>