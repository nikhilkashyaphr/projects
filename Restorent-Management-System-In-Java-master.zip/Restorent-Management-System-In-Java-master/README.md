# Restorent-Management-System-In-Java
  <p align="center">
   <img src="https://codenotfound.com/assets/images/logo/java-logo.png">
  </p>
  
  ## interface

  ![](https://github.com/sutharp777/Restorent-Management-System-In-Java/blob/master/output%20Screenshort/jo1.png)

  #### main menu

  ![](https://github.com/sutharp777/Restorent-Management-System-In-Java/blob/master/output%20Screenshort/jo3.png)

  #### Restorent Option

  ![](https://github.com/sutharp777/Restorent-Management-System-In-Java/blob/master/output%20Screenshort/jo4.png)

  #### Restorent Dishes

  ![](https://github.com/sutharp777/Restorent-Management-System-In-Java/blob/master/output%20Screenshort/jo5.png)

  #### Running

  ![](https://github.com/sutharp777/Restorent-Management-System-In-Java/blob/master/output%20Screenshort/jo6.png)

  #### Running

  ![](https://github.com/sutharp777/Restorent-Management-System-In-Java/blob/master/output%20Screenshort/jo7.png)

  #### Restorent menu

  ![](https://github.com/sutharp777/Restorent-Management-System-In-Java/blob/master/output%20Screenshort/jo8.png)
